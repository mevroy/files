CREATE DATABASE  IF NOT EXISTS `GROUPSALL` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `GROUPSALL`;
-- MySQL dump 10.13  Distrib 5.6.13, for osx10.6 (i386)
--
-- Host: localhost    Database: GROUPSALL
-- ------------------------------------------------------
-- Server version	5.7.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `group_sub_links`
--

DROP TABLE IF EXISTS `group_sub_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_sub_links` (
  `id` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `disabled` bit(1) DEFAULT NULL,
  `link_description` varchar(255) DEFAULT NULL,
  `link_href` varchar(255) NOT NULL,
  `link_java_script` varchar(255) DEFAULT NULL,
  `link_name` varchar(255) NOT NULL,
  `link_order` double DEFAULT NULL,
  `group_main_link_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `link_name` (`link_name`,`group_main_link_id`),
  KEY `FK7364DF3AC216DBFF` (`group_main_link_id`),
  CONSTRAINT `FK7364DF3AC216DBFF` FOREIGN KEY (`group_main_link_id`) REFERENCES `group_main_links` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_sub_links`
--

LOCK TABLES `group_sub_links` WRITE;
/*!40000 ALTER TABLE `group_sub_links` DISABLE KEYS */;
INSERT INTO `group_sub_links` VALUES ('09ac10ba-f763-4d90-9454-e69525b7caf1','2020-01-28 08:54:02',NULL,'2020-01-28 08:54:02',NULL,'\0','','userRegistration','','Register',99,1),('290591fa-a92f-4deb-a201-4d227ad85eca','2019-07-04 14:57:34',NULL,'2019-07-04 14:57:34',NULL,'\0','','#','','-------',2.1,4),('3218dbcf-3e71-4544-8bf4-577603758317','2020-01-25 14:21:41',NULL,'2020-01-25 14:21:41',NULL,'\0','','loadClientData','','Manage Clients',10,10),('333688a9-56dd-45fa-a9ba-51d61acd7a50','2019-07-04 15:04:23',NULL,'2019-07-04 15:04:23',NULL,'\0','','viewAllGroupMember','','Members View',1.1,6),('33f96ed9-3c4c-47af-b0da-39fdc8c685f3','2019-07-04 14:44:28',NULL,'2019-07-04 14:44:28',NULL,'\0','','#','','------',2,6),('40f608db-7847-4490-9305-3c304b09bb0e','2019-06-05 19:40:48',NULL,'2019-07-04 15:06:39',NULL,'\0','','viewAuditLogs','','Audit View',1,5),('4d819f94-ddea-4115-befd-eb93b4db702b','2020-01-28 08:52:51',NULL,'2020-01-28 08:52:51',NULL,'\0','','#','','-------',10,3),('59e5d295-b6ba-4cb1-b362-8ca4b22cd39c','2019-06-02 08:01:26',NULL,'2019-06-02 08:01:26',NULL,'\0','','#','','-------',1.1,1),('5d79b80a-074b-43a1-901c-d1d772dbfcd2','2019-07-04 15:32:41',NULL,'2019-07-04 15:32:41',NULL,'\0','','addGroupSMSTemplate','','SMS Template Add',4,7),('5e747561-d30b-47a6-b6b7-0c2834c809c3','2020-01-25 14:19:23',NULL,'2020-01-25 14:21:53',NULL,'\0','','addClientData','','Add Client',1,10),('6271ecf3-a9bb-42a9-8e15-17a9799ccf25','2019-07-16 16:21:34',NULL,'2019-07-16 16:21:34',NULL,'\0','','viewGroupEventTableAllocations','','Passes Table Allocations',4,9),('6f3a057b-bcfc-4b37-9388-df61c5c5d0ad','2020-01-27 11:06:41',NULL,'2020-01-27 11:06:41',NULL,'\0','','viewGroupWorkInstructionRecordsSelf','','View My Jobs',10,1),('7974ceb6-f052-457e-8b16-9518cdacc5e7','2019-05-31 16:03:38',NULL,'2019-05-31 17:58:00',NULL,'\0','','groupInstructionRecord','','New WIR',1,1),('799bedd5-2500-4195-bf75-9100431abd4a','2019-07-16 16:17:17',NULL,'2019-07-16 16:17:17',NULL,'\0','','#','','------',2,9),('820a906b-c36d-4f16-9e43-9a9208889ea2','2019-07-04 14:59:05',NULL,'2019-07-04 14:59:05',NULL,'\0','','addGroupEmailTemplate','','Email Template Add',2.2,4),('839f859b-5e90-4ce5-a849-ae336e0dbb19','2019-07-04 15:11:17',NULL,'2019-07-04 15:11:17',NULL,'\0','','#','','------',3,8),('83ded863-f9bd-4303-a42e-7f4e75974c0f','2020-01-25 14:02:20',NULL,'2020-01-25 14:02:48',NULL,'\0','','addGroupMemberGIES','','Add GIES Employees',1.2,6),('962d72e4-591a-4fa6-8b65-f36f217b17c6','2019-05-31 16:04:10',NULL,'2019-05-31 17:58:22',NULL,'\0','','viewGroupWorkInstructionRecords','','View WIRs',2,1),('969caefe-1e22-442a-ae20-8b68022fec30','2019-07-04 14:52:13',NULL,'2019-07-04 15:05:35',NULL,'\0','','viewGroupSMS','','SMS View',2,7),('98eb49dc-0ab9-4d7a-b99d-968a0d8ae167','2019-07-16 16:26:33',NULL,'2019-07-16 16:26:33',NULL,'\0','','addUnAssignedGroupEventPassesToGroupMembers','','Pass Assignment',2.1,9),('9afd1925-1111-4e54-9115-ec8c11800aec','2019-07-04 14:54:58',NULL,'2019-07-04 14:57:12',NULL,'\0','','createGroupEventInviteEmails','','Emails Send',1,4),('9bf22b46-71ff-4b8c-8201-4ba01993233f','2019-07-04 15:33:09',NULL,'2019-07-04 15:33:09',NULL,'\0','','viewAllGroupSMSTemplates','','SMS Template View',5,7),('9e328855-0781-49ee-ab12-85a84efa48a3','2019-07-16 16:26:08',NULL,'2019-07-16 16:26:08',NULL,'\0','','#','','-------',2.3,9),('a70ddfec-c307-4938-9440-75a0b0d4f38b','2020-01-27 22:56:36',NULL,'2020-01-28 08:52:57',NULL,'\0','','viewGroupContent','','Content Management',20,3),('a8496fc8-b118-4016-8ad2-2d2906e06e86','2019-07-04 14:59:42',NULL,'2019-07-04 14:59:42',NULL,'\0','','viewAllGroupEmailTemplates','','Email Template View',2.3,4),('b1932716-8d60-4b02-8bec-d5f9f7ffcee8','2019-06-02 07:59:16',NULL,'2019-07-04 15:06:28',NULL,'\0','','viewNavigationLinks','','Links Add/View',1,3),('b9c2218d-2743-4c6f-99bb-60ef88c03686','2019-06-02 08:00:18',NULL,'2019-07-04 14:57:47',NULL,'\0','','addGroupEmailAccount','','Email Account Add',3,4),('ba48a462-f43b-4176-8e0e-bbeccb120134','2019-07-16 16:20:27',NULL,'2019-07-16 16:20:27',NULL,'\0','','viewGroupEventPasses','','Passes View',3,9),('c740eac9-1f91-4e70-9215-6171d083c38f','2019-07-04 15:13:53',NULL,'2019-07-04 15:13:53',NULL,'\0','','#','','-------',5,8),('c755a6f0-0a13-41bc-8ad3-c894401ff998','2019-07-04 15:10:27',NULL,'2019-07-04 15:10:27',NULL,'\0','','addGroupEvent','','Events Add',1,8),('cb333812-eada-4b4b-87ad-c8fdfbde941e','2019-07-04 15:32:08',NULL,'2019-07-04 15:32:08',NULL,'\0','','#','','------',3,7),('cd9b3cee-3c8f-4d7a-b172-720a85d1ccf2','2019-07-16 16:16:04',NULL,'2019-07-16 16:16:19',NULL,'\0','','viewAllGroupEventsTickets','','Pass Categories Add/View',1,9),('db6b2a56-3454-4569-8d53-e7b72d44b37c','2019-07-04 14:42:56',NULL,'2019-07-04 15:04:44',NULL,'\0','','addGroupMember','','Members Add',1,6),('dbad4d7c-ea56-47f2-b16f-1f4ebbd01526','2019-07-04 14:59:56',NULL,'2019-07-04 14:59:56',NULL,'\0','','#','','--------',2.4,4),('dd1698b4-656f-4238-b9be-3c774a08b97e','2019-07-16 16:28:41',NULL,'2019-07-16 16:28:41',NULL,'\0','','registerGroupEventInvites','','Event Invites Update/Register',4.1,8),('df903806-3a75-4713-8df5-b25ffb01d46a','2020-01-27 08:53:21',NULL,'2020-01-27 08:53:21',NULL,'\0','','viewAllGroupMemberGIES','','View GIES Employees',1.3,6),('e3f94c15-c9b0-4b95-92a3-2837274a7831','2019-07-04 15:10:50',NULL,'2019-07-04 15:10:50',NULL,'\0','','viewAllGroupEvents','','Events View',2,8),('eb2ba515-b0f1-4af8-83a5-c178acc77797','2019-07-04 14:48:28',NULL,'2019-07-04 15:05:28',NULL,'\0','','createGroupEventInviteSMS','','SMS Send',1,7),('f0b93e8a-278f-4999-b21e-a50aed552018','2019-06-02 07:54:05',NULL,'2019-06-02 07:54:05',NULL,'','','viewAllGroupEmailTemplates','','View Templates',2,2),('f312d47a-10c6-4b5b-9c73-293a777af496','2019-06-02 07:53:18',NULL,'2019-07-04 15:41:27',NULL,'\0','','addGroupEventCron','','Schedule Jobs',1,2),('f6b8622f-0514-48cf-b75a-2c78397632d4','2019-07-04 14:54:25',NULL,'2019-07-04 14:57:19',NULL,'\0','','viewGroupEmails','','Emails View',2,4),('f6c4c4a2-e199-474b-a298-39a84370ab29','2019-07-04 15:12:35',NULL,'2019-07-04 15:13:10',NULL,'\0','','createGroupEventInvite','','Event Invites Create/View',4,8),('fe921ce6-75a6-4371-83fa-ae347bfaabcd','2019-07-04 14:45:00',NULL,'2019-07-04 15:04:53',NULL,'\0','','addGroupMemberCategory','','Member Category Add',3,6),('ff419ac8-8af9-47c9-b342-9122ba5c5e28','2019-07-04 15:14:32',NULL,'2019-07-04 15:14:32',NULL,'\0','','viewGroupEventPaymentTransactions','','Event Payments',6,8);
/*!40000 ALTER TABLE `group_sub_links` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-02-08 19:10:14
